using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyObject : MonoBehaviour
{
    public int escence;
    public GameObject collider1;
    public GameObject collider2;
    public GameObject collider3;
    public GameObject collider4;
    private int c = 0;

    void Update()
    {
        if(Estadisticas.Instance.esencia==escence && c==0)
        {
            //Sonido apertura de camino.
            c=1;
            switch (Randomaizer(5))
            {
                case 1:
                    Destroy(collider1);
                    break;
                case 2:
                    Destroy(collider2);
                    break;
                case 3:
                    Destroy(collider3);
                    break;
                case 4:
                    Destroy(collider4);
                    break;
                default:
                    break;
            }
        }
    }

    private int Randomaizer(int max)
    {
        int i = UnityEngine.Random.Range(1, max);
        return i;
    }
}

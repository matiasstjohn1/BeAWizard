using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;

public class LifePlayer : MonoBehaviour
{
    //Variables de vida.

    public int maxHealth; //Maximo de vida
    public float currentHealth; //Vida que llevas en el juego
    public float damageCooldown = 1f; //Da�o

    //Llamar para Pop de Pila.
    private EscenceCollector player;

    private Animator anim;
    private SpriteRenderer spriteRenderer; //Renderizado color

    private float currentTime;
    public event Action OnDeath; //Muerte del jugador como evento.

    public Text Vida; //Texto del canvas que implica la vida (estadisticas UI)
    public Image lifeImage; //Imagen barra

    //Color al recibir da�o.
    public Color damageColor = Color.red;
    private Color originalColor;

    private void Start()
    {
        currentHealth = maxHealth;
        spriteRenderer = GetComponent<SpriteRenderer>();
        originalColor = spriteRenderer.color;
        player = GetComponent<EscenceCollector>();
        anim =GetComponent<Animator>();
    }

    private void Update()
    {
        maxHealth=Estadisticas.Instance.vida;

        currentTime += Time.deltaTime;
        //Da�o
        if (currentHealth <= 0)
        {
            Die();
        }

        if (currentHealth > maxHealth)
        {
            currentHealth = maxHealth;
            
        }
        lifeImage.fillAmount = currentHealth / maxHealth;
        Vida.text = "Vida " + currentHealth;
    }

    //Recibe veneno
    private void OnCollisionEnter2D(Collision2D collision)
    {
        //Da�o de veneno.
        //if (collision.gameObject.layer == 17)
        //{
        //    currentHealth = currentHealth - 1;
        //    if (currentHealth <= 0)
        //    {
        //        Die();
        //    }
        //}
    } 

    //Recibie da�o
    public void GetDamage(int value)
    {
        currentHealth -= value; //currentHealth = currentHealth - value;
        spriteRenderer.color = damageColor;
        Invoke("RestoreColor", 0.5f);
        player.RestarPuntos();        ////MARTES IMPORTANTE///.
    }
    private void RestoreColor()
    {
        // Restaurar el color original del sprite
        spriteRenderer.color = originalColor;
    }

    //Muere
    private void Die()
    {
        anim.SetTrigger("Death");
        Destroy(gameObject,1f);
        OnDeath?.Invoke();
    }
}

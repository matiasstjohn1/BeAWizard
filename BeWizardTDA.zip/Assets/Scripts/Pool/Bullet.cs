using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    //Da�o
    private float damage;

    private void Update()
    {
       damage = Estadisticas.Instance.dano;
    }

    // Colision pared con bala.
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.layer == 6)
        {
            collision.gameObject.GetComponent<ChildLife>().GetDamage(damage); 
            DeactivateBullet(); //Desactivar la bala.
        }
        if (collision.gameObject.layer == 11)
        {
            DeactivateBullet();
        }
    }

    //M�todo para desactivar la bala.
    private void DeactivateBullet()
    {
        gameObject.SetActive(false);
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;
    public int contador = 0;

    //Personaje
    [SerializeField] GameObject player; 

    //Stats importantes
    public float escence = Estadisticas.Instance.esencia; 

    //Textos de stats.
    public Text textocount; 
    public GameObject stats;
    private bool statsActivo = true;

    private void Awake()
    {
       
        if (Instance == null)
            Instance = this;
        else
            Destroy(this);

        player.GetComponent<LifePlayer>().OnDeath += FinishGame;
    }

    private void Update()
    {
        //if (Input.GetKeyDown(KeyCode.Escape))
        //{
        //    SceneManager.LoadScene(0);
        //}
        if (Input.GetKeyDown(KeyCode.Tab))
        {
            statsActivo = !statsActivo; 
            stats.SetActive(statsActivo); 
        }
        //CompleteGame();
    }

    //void CompleteGame()
    //{
    //    if (escence >= 15)
    //    {
    //        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    //    }
    //}

    void FinishGame()
    {
        SceneManager.LoadScene(5);
    }

    //Scenes y como pasarlas.
    public void GoToMenu()
    {
        SceneManager.LoadScene(0);
    }
    public void RestartGame()
    {
        SceneManager.LoadScene(1);
    }
    public void ButtonPlay()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
    public void ExitGame()
    {
        Application.Quit();
    }
    public void Config()
    {
        SceneManager.LoadScene(6);
    }
}

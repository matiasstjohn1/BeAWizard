using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionItems : MonoBehaviour
{
    //Lista.
    [SerializeField] List<ItemData> items;

    [System.Serializable]
    public class ItemData
    {
        public StatType type;
        public int amount;
    }

    public enum StatType
    {
        attack,
        vel,
        life,
        mana
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Player player = collision.gameObject.GetComponent<Player>();

            foreach (ItemData item in items)
            {
                ApplyItemEffect(player, item);
            }

            Destroy(gameObject);
        }
    }

    private void ApplyItemEffect(Player player, ItemData item)
    {
        switch (item.type)
        {
            case StatType.attack:
                Estadisticas.Instance.dano += item.amount;
                break;
            case StatType.vel:
                Estadisticas.Instance.vel += item.amount;
                break;
            case StatType.life:
                player.GetComponent<LifePlayer>().currentHealth += item.amount;
                Estadisticas.Instance.vida += item.amount;
                break;
            case StatType.mana:
                Estadisticas.Instance.mana += item.amount;
                player.GetComponent<ManaPlayer>().currentMana += item.amount;
                break;
        }
    }
}

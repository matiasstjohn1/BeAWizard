using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EscenceCollector : MonoBehaviour
{
    private ManaPlayer Mana;

    //Pila.
    public Stack<GameObject> escenceInCollision = new Stack<GameObject>();

    private void Start()
    {
        Mana = GetComponent<ManaPlayer>();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Escence"))
        {
            GameObject escence = other.gameObject;
            escenceInCollision.Push(escence); 
            escence.SetActive(false); 
            SumarPuntos(); 
        }
    }

    private void SumarPuntos()
    {
        //Sumar puntos.
        Mana.maxMana = Mana.maxMana+10;
        Mana.currentMana = Mana.currentMana + 10;
        Estadisticas.Instance.esencia = Estadisticas.Instance.esencia + 1;
        Debug.Log("�Escencia recogida! Puntos +1");
    }
    
    public void RestarPuntos()
    {
        //Restar puntos.
        if(escenceInCollision.Count > 0)
        {
            Estadisticas.Instance.esencia = Estadisticas.Instance.esencia - 1;
            GameObject escence = escenceInCollision.Pop(); 
            Debug.Log("�Escencia perdida! Puntos -1");
        }
    }
}

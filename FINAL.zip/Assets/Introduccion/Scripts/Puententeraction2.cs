using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Puententeraction2 : MonoBehaviour
{
    //Variables para interactuar con mascara. Maximo 3 textos por longitud de gui�n.
    [SerializeField] GameObject Lectura;
    [SerializeField] GameObject Lectura2;
    [SerializeField] GameObject Lectura3;
    [SerializeField] GameObject Lectura4;
    [SerializeField] GameObject Lectura5;
    [SerializeField] GameObject Lectura6;
    [SerializeField] GameObject Lectura7;
    [SerializeField] GameObject Lectura8;
    [SerializeField] GameObject Lectura9;
    [SerializeField] GameObject Lectura10;
    [SerializeField] GameObject Lectura11;

    private float currentTime;
    private int i = 0;

    //Contador para los textos (si se pasa de largo desaparece).
    void Update()
    {
        currentTime += Time.deltaTime;

        if (currentTime >= 80)
        {
            currentTime = 0;
            Lectura.SetActive(false);
            Lectura2.SetActive(false);
            Lectura3.SetActive(false);
            Lectura4.SetActive(false);
            Lectura5.SetActive(false);
            Lectura6.SetActive(false);
            Lectura7.SetActive(false);
            Lectura8.SetActive(false);
            Lectura9.SetActive(false);
            Lectura10.SetActive(false);
            Lectura11.SetActive(false);
        }
    }

    //Activacio por trigger en un bloque invisible a los textos.
    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player") && i == 0)
        {
            //Primera interaccion.
            Lectura.SetActive(true);

            //Segunda interaccion.
            if (currentTime >= 4)
            {
                Lectura.SetActive(false);
                Lectura2.SetActive(true);
            }

            //Tercera interaccion.
            if (currentTime >= 8)
            {
                Lectura2.SetActive(false);
                Lectura3.SetActive(true);
            }

            //Cuarta interaccion.
            if (currentTime >= 14)
            {
                Lectura3.SetActive(false);
                Lectura4.SetActive(true);
            } 
            
            //Quinta interaccion.
            if (currentTime >= 20)
            {
                Lectura4.SetActive(false);
                Lectura5.SetActive(true);
            }

            //Sexta interaccion.
            if (currentTime >= 26)
            {
                Lectura5.SetActive(false);
                Lectura6.SetActive(true);
            }

            //Septima interaccion.
            if (currentTime >= 35)
            {
                Lectura6.SetActive(false);
                Lectura7.SetActive(true);
            }   
            
            //Octava interaccion.
            if (currentTime >= 44)
            {
                Lectura7.SetActive(false);
                Lectura8.SetActive(true);
            }

            if (currentTime >= 53)
            {
                Lectura8.SetActive(false);
                Lectura9.SetActive(true);
            }
            if (currentTime >= 62)
            {
                Lectura9.SetActive(false);
                Lectura10.SetActive(true);
            }
            if (currentTime >= 71)
            {
                Lectura10.SetActive(false);
                Lectura11.SetActive(true);
                i = 1;
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            currentTime = 0;
        }
    }
    void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            Lectura.SetActive(false);
            Lectura2.SetActive(false);
            Lectura3.SetActive(false);
            Lectura4.SetActive(false);
            Lectura5.SetActive(false);
            Lectura6.SetActive(false); 
            Lectura7.SetActive(false);
            Lectura8.SetActive(false);
            Lectura9.SetActive(false);
            Lectura10.SetActive(false);
            Lectura11.SetActive(false);
        }
    }
}

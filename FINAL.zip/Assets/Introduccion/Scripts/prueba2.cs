using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class prueba2 : MonoBehaviour //Se llama asi porque probamos cosas y no se cambio.
{
    //Variables del codigo.
    [SerializeField] GameObject Interaccion; //Texto que sale para interactuar
    [SerializeField] GameObject Lectura; //Texto que sale para leer
    [SerializeField] GameObject Lectura2;
    [SerializeField] GameObject Lectura3;
    [SerializeField] GameObject Lectura4;
    [SerializeField] GameObject Lectura5;
    [SerializeField] GameObject Lectura6;
    [SerializeField] GameObject Lectura7;

    //Tiempo.
    private float currentTime;
    private int i = 0;
    private int u = 0;

    //Filtro.
    private Collider2D z_Collider;  //Colision del objeto que podes clickear
    [SerializeField]
    private ContactFilter2D z_Filter; //Filtro de lo que tiene que chocar para activarse.
    private List<Collider2D> z_CollidedObjects = new List<Collider2D>(1);

    [SerializeField] GameObject portal; //Activa el portal
    
    void Start()
    {
        z_Collider = GetComponent<Collider2D>();
    }

    //Generamos la tecla H y llamamos a los textos segun la colision.
    void Update()
    {    
        currentTime += Time.deltaTime;

        z_Collider.OverlapCollider(z_Filter, z_CollidedObjects);
        foreach(var o  in z_CollidedObjects)
        {
            if (Input.GetKeyDown(KeyCode.H) && u == 0)
            {
                u = 1;
                Lectura.SetActive(true);
                Interaccion.SetActive(false);   
                currentTime = 0;
            }
        }

        if (currentTime >= 40)
        {
            Lectura.SetActive(false);
            Lectura2.SetActive(false);
            Lectura3.SetActive(false);
            Lectura4.SetActive(false);
            Lectura5.SetActive(false);
            Lectura6.SetActive(false);
            Lectura7.SetActive(false);

        }
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player") && i == 0 && u == 1)
        {
            //Primera interaccion.
            Lectura.SetActive(true);

            //Segunda interaccion.
            if (currentTime >= 4)
            {
                Lectura.SetActive(false);
                Lectura2.SetActive(true);
            }

            //Tercera interaccion.
            if (currentTime >= 8)
            {
                Lectura2.SetActive(false);
                Lectura3.SetActive(true);
            }

            //Cuarta interaccion.
            if (currentTime >= 14)
            {
                Lectura3.SetActive(false);
                Lectura4.SetActive(true);
            }

            //Quinta interaccion.
            if (currentTime >= 20)
            {
                Lectura4.SetActive(false);
                Lectura5.SetActive(true);
            }

            //Sexta interaccion.
            if (currentTime >= 26)
            {
                Lectura5.SetActive(false);
                Lectura6.SetActive(true);
            }

            //Septima interaccion.
            if (currentTime >= 35)
            {
                Lectura6.SetActive(false);
                Lectura7.SetActive(true);
                i = 1;
                u = 0;
                portal.SetActive(true);
            }
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Interaccion.SetActive(true);
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        Interaccion.SetActive(false);
        Lectura.SetActive(false);
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerIntro : MonoBehaviour, IMovable
{
    //Variables de interfaz IMovable//
    public int Speed => speed;
    public Rigidbody2D Rigidbody => rigidbody;

    private Rigidbody2D rigidbody;
    private float currentTime;

    //Animaciones.
    private Animator anim;

    //Velocidad
    private int speed;


    private void Start()
    {
        rigidbody = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    private void Update()
    {
        speed = Estadisticas.Instance.vel;
        //Movimiento del personaje
        float horizontal = Input.GetAxis("Horizontal");
        float vertical = Input.GetAxis("Vertical");

        rigidbody.velocity = new Vector3(horizontal* speed, vertical* speed, 0);

    }
}

using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawner : MonoBehaviour
{
    //Cola.
    public GameObject enemigoPrefab;
    [SerializeField] float tiempoEntreEnemigos = 3f;
    [SerializeField] Transform[] spawnPoints; 
    private float tiempoDesdeUltimoEnemigo = 0f;
    private int i;

    public Queue<Transform> spawnPointsQueue = new Queue<Transform>();

    private void Start()
    {
        //Cola con spawns.
        foreach (Transform spawnPoint in spawnPoints)
        {
            spawnPointsQueue.Enqueue(spawnPoint);
        }
    }

    void Update()
    {
        tiempoDesdeUltimoEnemigo += Time.deltaTime;

        if (tiempoDesdeUltimoEnemigo >= tiempoEntreEnemigos)
        {
            i = UnityEngine.Random.Range(1, 7);
            GenerarSpawner(i);
            i += 1;
            if (i == 3)
            {
                tiempoEntreEnemigos = 2;
            }
            tiempoDesdeUltimoEnemigo = 0f;
        }
    }

    private void GenerarSpawner(int r)
    {
        if (spawnPointsQueue.Count > 0)
        {
            Transform spawnPoint = spawnPointsQueue.Dequeue();
            switch (r)
            {
                case 1:
                    Instantiate(enemigoPrefab, spawnPoint.position, spawnPoint.rotation);
                    break;
                case 2:
                    Instantiate(enemigoPrefab, spawnPoint.position, spawnPoint.rotation);
                    break;
                case 3:
                    Instantiate(enemigoPrefab, spawnPoint.position, spawnPoint.rotation);
                    break;
                case 4:
                    Instantiate(enemigoPrefab, spawnPoint.position, spawnPoint.rotation);
                    break;
                case 5:
                    Instantiate(enemigoPrefab, spawnPoint.position, spawnPoint.rotation);
                    break;
                case 6:
                    Instantiate(enemigoPrefab, spawnPoint.position, spawnPoint.rotation);
                    break;
                default:
                    break;
            }
        }
    }
}


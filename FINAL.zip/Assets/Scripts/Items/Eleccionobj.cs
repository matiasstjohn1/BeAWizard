using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Eleccionobj : MonoBehaviour
{
    //Permite elegir cual bloqueo quitar de la zona segura en el nivel 6
    [SerializeField] GameObject item1;

    private void OnCollisionEnter2D(Collision2D collision)
    {
        //Item segun la piedra
        if (collision.gameObject.layer == 3 )
        {
            Destroy(item1);
        }
    }
}

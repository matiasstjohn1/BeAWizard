using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ManagerDeRondas : MonoBehaviour
{

    public int[] rondas = { 3, 6, 4, 7, 5, 8, 10, 9 }; //Niveles a ordenar (scenes/zonas). 

    public static ManagerDeRondas Instance;
    public int a =0;
    // Start is called before the first frame update
    private void Awake()
    {
        if (ManagerDeRondas.Instance == null)
        {
            ManagerDeRondas.Instance = this;
            DontDestroyOnLoad(this.gameObject);
        }
        else
        {
            Destroy(this.gameObject);
        }

    }
}

using UnityEngine;

public class EscenceScore : MonoBehaviour
{
    public int Puntaje { get; set; }

    public EscenceScore(int puntaje)
    {
        this.Puntaje = puntaje;
    }
}

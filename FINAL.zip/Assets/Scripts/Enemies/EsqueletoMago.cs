using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EsqueletoMago : MonoBehaviour
{
    [SerializeField] GameObject follow;
    public Transform player;
    [SerializeField] float distToAttack;
    [SerializeField] float Vel;
    [SerializeField] float attackDelay;//tiene que ser mas grande que closest
    [SerializeField] float closestDist;
    [SerializeField] float lerpSpeedRotation;
    public GameObject bala;
    public Transform weaponSlot;
    Rigidbody2D rb;
    Vector3 enemyDirection;
    Animator anim;
    private bool isFacingRight = true;
    public int damage;
    private float currentTime;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    private void FixedUpdate()
    {
        rb.velocity = enemyDirection.normalized * Vel;
    }

    private void Update()
    {
        currentTime += Time.deltaTime;
        Vector2 targetDir = player.position - transform.position;
        float angle = Mathf.Atan2(targetDir.y, targetDir.x)*Mathf.Rad2Deg;
        Quaternion q = Quaternion.Euler(new Vector3(0, 0, angle));
        //Movimiento.
        enemyDirection = follow.transform.position - transform.position;
        //transform.right = Vector3.Lerp(transform.right, enemyDirection, lerpSpeedRotation * Time.deltaTime);
        if (enemyDirection.magnitude <  distToAttack && enemyDirection.magnitude>closestDist)
        {
            transform.right = Vector3.Lerp(transform.right, enemyDirection, lerpSpeedRotation * Time.deltaTime);
        }
        if (enemyDirection.magnitude > distToAttack || enemyDirection.magnitude < closestDist)
        {
            if (currentTime >= attackDelay)
            {
                anim.SetTrigger("Attack");
                
                if (currentTime >= attackDelay+1.5)
                {
                    Instantiate(bala, weaponSlot.position, q);
                    currentTime = 0;
                }
                
            }
            
            enemyDirection = Vector3.zero;
        }
        if (transform.position.x < player.position.x && !isFacingRight)
        {
            Flip();
        }
        else if (transform.position.x > player.position.x && isFacingRight)
        {
            Flip();
        }
    }
    //Deteccion del radio basada en Gizmos.
    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, distToAttack);
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position, closestDist);
    }

    //Colision con jugador
    private void OnCollisionStay2D(Collision2D collision)
    {
        if (currentTime >= attackDelay)
        {
            if (collision.gameObject.layer == 3)
            {
                collision.gameObject.GetComponent<LifePlayer>().GetDamage(damage);
                currentTime = 0;
            }
        }
    }

    //Giro.
    private void Flip()
    {
        isFacingRight = !isFacingRight;
        transform.localScale = new Vector3(-transform.localScale.x, transform.localScale.y, transform.localScale.z);
    }
    public void OnDeath()
    {
        anim.SetTrigger("Death");
        Destroy(gameObject);
    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Jefe : MonoBehaviour
{
    ///Variables jefe///
    private Rigidbody2D rigidbody;
    private float currentTime;
    [SerializeField] GameObject follow; //Mirar al jugador y seguirlo.
    public Transform player; //Ubiacion del jugador.
    [SerializeField] float distToAttack; //Distancia dispara de bola.
    [SerializeField] float attackVel; //Velocidad disparo de bola.
    [SerializeField] float closestDist; //Distancia que tan cerca llega a disparar.
    [SerializeField] float lerpSpeedRotation;
    Vector3 enemyDirection;

    //Animaciones.
    private Animator anim;
    
    //Estadisticas del jefe.
    public Image nick;
    public Image lifeImage; //Imagen barra

    //Puntos de TP
    [SerializeField] Transform Point1;
    [SerializeField] Transform Point2;
    [SerializeField] Transform Point3;
    [SerializeField] Transform Point4;

    //Disparo
    [SerializeField] GameObject disparoRota;
    [SerializeField] GameObject disparoSigue;
    [SerializeField] float tiempoEntreDisparo = 8f;
    [SerializeField] int cantidadDisparo = 4;
    private float tiempoDesdeUltimoDisparo = 0f;
    [SerializeField] Transform spawnPointAtaque;
    private int i = 0;
    private int g;

    //Llamo Vida
    private ChildLife jefe;

    //AudioManager.instance.PlaySound(0);

    // Start is called before the first frame update
    void Start()
    {
        rigidbody = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        jefe = GetComponent<ChildLife>();
    }

    // Update is called once per frame
    void Update()
    {
        currentTime += Time.deltaTime;

        g = UnityEngine.Random.Range(1, 5);

        lifeImage.fillAmount = jefe.health / 500;

        tiempoDesdeUltimoDisparo += Time.deltaTime;

        //Dispara desde el punto de spawn.
        if (tiempoDesdeUltimoDisparo >= tiempoEntreDisparo)
        {
             anim.SetTrigger("ShootUp");
             tiempoEntreDisparo = 3;
             GenerarAtaqueFuego();

             i += 1;
             if (i == 3)
             {
               tiempoEntreDisparo = 9;
             }
           tiempoDesdeUltimoDisparo = 0f;
        }

        //If para los TPs
        if (currentTime >= 10)
        {
            anim.SetTrigger("Damage");
            HacerTps(g);
            currentTime = 0;
        }

        //Dispara desde el enemigo.
        if (currentTime >= 5 && currentTime <= 5.01f)
        {
            anim.SetTrigger("ShootUp");
            GenerarAtaque2();
        }

        if (jefe.health <=0)
        {
            GameManager.Instance.CompleteGame();
        }
    }

    private void GenerarAtaqueFuego()
    {
        float anguloEntreBolas = 360f / cantidadDisparo;

        for (int i = 0; i < cantidadDisparo; i++)
        {
            float anguloActual = i * anguloEntreBolas;
            Quaternion rotacion = Quaternion.Euler(0f, 0f, anguloActual);

            // Generar una bola de fuego en la posici�n del spawnPoint con la rotaci�n adecuada
            GameObject shoot = Instantiate(disparoRota, spawnPointAtaque.position, rotacion);
        }
    }

    private void GenerarAtaque2()
    {
        //Genera bola de ataque
        Instantiate(disparoSigue, transform.position, Quaternion.identity);
    }

    private void HacerTps(int r)
    {
        switch (r)
        {
            case 1:
                transform.position = Point1.position;
                break;
            case 2:
                transform.position = Point2.position;
                break;
            case 3:
                transform.position = Point3.position;
                break;
            case 4:
                transform.position = Point4.position;
                break;
            default:
                break;
        }
    }
}

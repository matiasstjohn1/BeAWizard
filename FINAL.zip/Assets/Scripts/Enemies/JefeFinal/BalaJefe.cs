using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BalaJefe : MonoBehaviour
{
    public float distToAttack;
    public float Vel;
    public float attackDelay;
    public float closestDist;
    public float lerpSpeedRotation;
    public int damage;

    private Transform player;
    private Rigidbody2D rb;
    private Animator anim;
    private float currentTime;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        GetTarget();
    }

    private void FixedUpdate()
    {
        if (player)
        {
            MoveTowardsPlayer();
        }
    }

    private void Update()
    {
        currentTime += Time.deltaTime;

        if (player)
        {
            UpdateDirection();
        }

        if(currentTime >=4)
        {
            Destroy(gameObject);
        }
    }

    private void MoveTowardsPlayer()
    {
        Vector3 direction = player.position - transform.position;
        rb.velocity = direction.normalized * Vel;
    }

    private void UpdateDirection()
    {
        if (Vector3.Distance(transform.position, player.position) > distToAttack || Vector3.Distance(transform.position, player.position) < closestDist)
        {
            rb.velocity = Vector3.zero;
        }
    }

    // Deteccion del radio basada en Gizmos.
    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, distToAttack);
    }

    // Colision con jugador
    private void OnCollisionStay2D(Collision2D collision)
    {
       if (collision.gameObject.layer == 3)
       {
          collision.gameObject.GetComponent<LifePlayer>().GetDamage(damage);
          Destroy(gameObject);
        }
    }

    private void GetTarget()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
    }
}

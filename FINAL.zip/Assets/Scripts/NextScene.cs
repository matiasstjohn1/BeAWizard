using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class NextScene : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.layer == 3)
        {
             Tree treeScript = FindObjectOfType<Tree>();
             AudioManager.instance.PlaySound(3);

            if (ManagerDeRondas.Instance.a==8)
            {
                SceneManager.LoadScene(10);
            }
            
            if (treeScript != null && ManagerDeRondas.Instance.rondas.Length > 0)
            {
                treeScript.SelectTree(Random.Range(0, 6));
                int siguienteEscena = ManagerDeRondas.Instance.rondas[ManagerDeRondas.Instance.a];
                ManagerDeRondas.Instance.a += 1;

               SceneManager.LoadScene(siguienteEscena);
            }

            else
            {
              Debug.LogError("");
            }
        }

    }
}

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tree : MonoBehaviour
{
    public class NodoABB
    {
        public int info;
        public NodoABB hijoIzq = null;
        public NodoABB hijoDer = null;
    }

    public class ABB
    {
        public NodoABB raiz;

        public int Raiz()
        {
            return raiz.info;
        }

        public bool ArbolVacio()
        {
            return (raiz == null);
        }

        public void InicializarArbol()
        {
            raiz = null;
        }

        public NodoABB HijoDer()
        {
            return raiz.hijoDer;
        }

        public NodoABB HijoIzq()
        {
            return raiz.hijoIzq;
        }

        public void AgregarElem(ref NodoABB raiz, int x)
        {
            if (raiz == null)
            {
                raiz = new NodoABB();
                raiz.info = x;
            }
            else if (raiz.info > x)
            {
                AgregarElem(ref raiz.hijoIzq, x);
            }
            else if (raiz.info < x)
            {
                AgregarElem(ref raiz.hijoDer, x);
            }
        }

        public void EliminarElem(ref NodoABB raiz, int x)
        {
            if (raiz != null)
            {
                if (raiz.info == x && (raiz.hijoIzq == null) && (raiz.hijoDer == null))
                {
                    raiz = null;
                }
                else if (raiz.info == x && raiz.hijoIzq != null)
                {
                    raiz.info = this.mayor(raiz.hijoIzq);
                    EliminarElem(ref raiz.hijoIzq, raiz.info);
                }
                else if (raiz.info == x && raiz.hijoIzq == null)
                {
                    raiz.info = this.menor(raiz.hijoDer);
                    EliminarElem(ref raiz.hijoDer, raiz.info);
                }
                else if (raiz.info < x)
                {
                    EliminarElem(ref raiz.hijoDer, x);
                }
                else
                {
                    EliminarElem(ref raiz.hijoIzq, x);
                }
            }
        }

        public int mayor(NodoABB a)
        {
            if (a.hijoDer == null)
            {
                return a.info;
            }
            else
            {
                return mayor(a.hijoDer);
            }
        }

        public int menor(NodoABB a)
        {
            if (a.hijoIzq == null)
            {
                return a.info;
            }
            else
            {
                return menor(a.hijoIzq);
            }
        }
    }
 

    ABB arbol = new ABB();

    private void Start()
    {
        arbol.InicializarArbol();

        for (int i = 0; i <ManagerDeRondas.Instance.rondas.Length; i++)
        {
            arbol.AgregarElem(ref arbol.raiz, ManagerDeRondas.Instance.rondas[i]);
        }
    }
    //Random de como recorrer el ABB. (luego utilizar esa).
    //private void Update()
    //{
    //    preOrder(arbol.raiz);
    //    inOrder(arbol.raiz);
    //    postOrder(arbol.raiz);
    //    level_Order(arbol.raiz);
    //    preOrder_FE(arbol.raiz);
    //}
    public void SelectTree(int a)
    {
        switch (a) 
        {
            case 1:
                preOrder(arbol.raiz);
                break;
            case 2:
                inOrder(arbol.raiz);
                break;
            case 3:
                postOrder(arbol.raiz);
                break;
            case 4:
                level_Order(arbol.raiz);
                break;
            case 5:
                preOrder_FE(arbol.raiz);
                break;
            default:
                break;
        }
            
    }

    private void preOrder_FE(NodoABB a)
    {
        if (a != null)
        {
            preOrder_FE(a.hijoIzq);
            preOrder_FE(a.hijoDer);
        }
    }

    private void preOrder(NodoABB a)
    {
        if (a != null)
        {
            preOrder(a.hijoIzq);
            preOrder(a.hijoDer);
        }
    }

    private void inOrder(NodoABB a)
    {
        if (a != null)
        {
            inOrder(a.hijoIzq);
            inOrder(a.hijoDer);
        }
    }

    private void postOrder(NodoABB a)
    {
        if (a != null)
        {
            postOrder(a.hijoIzq);
            postOrder(a.hijoDer);
        }
    }

    private void level_Order(NodoABB nodo)
    {
        Queue<NodoABB> q = new Queue<NodoABB>();

        q.Enqueue(nodo);

        while (q.Count > 0)
        {
            nodo = q.Dequeue();

            if (nodo.hijoIzq != null) { q.Enqueue(nodo.hijoIzq); }

            if (nodo.hijoDer != null) { q.Enqueue(nodo.hijoDer); }
        }
    }
}


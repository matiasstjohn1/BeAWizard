using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PilaTF : IPila
{
    GameObject[] _escences;
    int _index;

    public void InitializeStack()
    {
        _escences = new GameObject[200];
        _index = 0;
        Debug.Log($"{_index} ten�s");
    }

    public void Stack(GameObject x)
    {
        _escences[_index] = x;
        _index++;
        Debug.Log($"{_index} ten�s");
    }

    public void Unstack()
    {
        _index--;
        Debug.Log($"{_index} ten�s");
    }

    public bool EmptyStack()
    {
        return (_index == 0);
    }

    public GameObject Top()
    {
        return _escences[_index - 1];
    }

    public int Count(int x)
    {
        x = _index;
        return x;
    }
}

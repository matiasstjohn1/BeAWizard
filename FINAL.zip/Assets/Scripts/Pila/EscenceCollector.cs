using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EscenceCollector : MonoBehaviour
{
    PilaTF _pl1 = new PilaTF(); //Pila de los profes.
    private ManaPlayer Mana;

    public int escenseCount = 0; //Puntaje.

    private void Start()
    {
        _pl1.InitializeStack();
        Mana = GetComponent<ManaPlayer>();
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Escence"))
        {
            GameObject escence = other.gameObject;
            _pl1.Stack(escence);
            escence.SetActive(false); 
            SumarPuntos(); 
        }
    }

    private void SumarPuntos()
    {
        //Sumar puntos.
        Mana.maxMana = Mana.maxMana+10;
        Mana.currentMana = Mana.currentMana + 10;
        GameManager.Instance.escence = GameManager.Instance.escence + 1;
        Estadisticas.Instance.puntos= Estadisticas.Instance.puntos+ 1;
        escenseCount = Estadisticas.Instance.puntos;
    }
    
    public void RestarPuntos()
    {
        //Restar puntos.
        if (_pl1.Count(1) > 0)
        {
            GameManager.Instance.escence = GameManager.Instance.escence - 1;
            Estadisticas.Instance.puntos = Estadisticas.Instance.puntos - 1;
            escenseCount = Estadisticas.Instance.puntos;
            _pl1.Unstack();           
        }
    }
}

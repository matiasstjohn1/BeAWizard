using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IPila
{
    //Inicializar Pila//
    void InitializeStack();
    //Apilar//
    void Stack(GameObject x);
    //Desapilar//
    void Unstack();
    //Pila Vac�a//
    bool EmptyStack();
    //Tope//
    GameObject Top();
    //Count//
    int Count(int x);
}

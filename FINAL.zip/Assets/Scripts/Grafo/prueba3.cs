using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class prueba3 : MonoBehaviour
{
    [SerializeField] GameObject Interaccion;
    [SerializeField] GameObject[] Lecturas;
    [SerializeField] GameObject portal;
    private int interaccionActual = -1;
    private float tiempoEntreDialogos = 5f;
    private float tiempoUltimoDialogo;

    private Collider2D z_Collider;
    [SerializeField] private ContactFilter2D z_Filter;
    private List<Collider2D> z_CollidedObjects = new List<Collider2D>(1);

    private GrafoManager grafoManager;
    private AudioSource audioSource;

    private int a=0; //Identificador

    void Start()
    {
        z_Collider = GetComponent<Collider2D>();
        grafoManager = FindObjectOfType<GrafoManager>();
        tiempoUltimoDialogo = Time.time;
        audioSource = GetComponent<AudioSource>();
    }

    void Update()
    {
        float currentTime = Time.time;

        z_Collider.OverlapCollider(z_Filter, z_CollidedObjects);
        foreach (var o in z_CollidedObjects)
        {
            if (Input.GetKeyDown(KeyCode.H))
            {
                if (o.CompareTag("Player")&& a==0)
                {
                    InteractuarConObjeto();
                    a=1;
                }
                else if (o.CompareTag("Player")&&a==1)
                {
                    InteractuarConNuevoObjeto();
                    a=2;
                }
                 else if (o.CompareTag("Player")&&a==2)
                {
                    InteractuarConNPC();
                    a=0;
                }
            }
        }

        if (interaccionActual >= 0 && interaccionActual < Lecturas.Length)
        {
            MostrarInteraccion();
        }

        if (currentTime >= tiempoUltimoDialogo + 40)
        {
            OcultarTodasLasInteracciones();
        }
    }

    private void InteractuarConObjeto()
    {
        int jugador = 101; // ID player
        int objeto = 102; // ID objeto
        if (grafoManager.grafoInteracciones.ExisteArista(jugador, objeto))
        {
            EjecutarInteraccion();
        }
    }

    private void InteractuarConNuevoObjeto()
    {
        int jugador = 101; // ID player
        int nuevoObjeto = 103; // ID Nuevo Objeto
        if (grafoManager.grafoInteracciones.ExisteArista(jugador, nuevoObjeto))
        {
            EjecutarInteraccion();
        }
    }

    private void InteractuarConNPC()
    {
        int jugador = 101; // ID player
        int npc = 104; // ID NPC
        // Verificar si existe una conexión entre el jugador y el NPC.
        if (grafoManager.grafoInteracciones.ExisteArista(jugador, npc))
        {
            EjecutarInteraccion();
        }
    }

    private void EjecutarInteraccion()
    {
        MostrarInteraccion();
        audioSource.Play();
        Interaccion.SetActive(false);
        tiempoUltimoDialogo = Time.time + 7;
    }

    private void MostrarInteraccion()
    {
        float currentTime = Time.time;

        if (currentTime - tiempoUltimoDialogo >= tiempoEntreDialogos)
        {
            interaccionActual++;

            if (interaccionActual >= 0 && interaccionActual < Lecturas.Length+1)
            {
                OcultarTodasLasInteracciones();
                Lecturas[interaccionActual].SetActive(true);

                if (interaccionActual == Lecturas.Length - 1)
                {
                    portal.SetActive(true);
                }

                tiempoUltimoDialogo = currentTime;
            }
        }
    }

    private void OcultarTodasLasInteracciones()
    {
        foreach (var lectura in Lecturas)
        {
            lectura.SetActive(false);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Interaccion.SetActive(true);
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        Interaccion.SetActive(false);
    }
}

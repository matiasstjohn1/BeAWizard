using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface GrafoTDA
{
    void InicializarGrafo();
    void AgregarVertice(int v);
    void EliminarVertice(int v);
    ConjuntoTDA Vertices();
    void AgregarArista(int id, int v1, int v2, int peso);
    void EliminarArista(int v1, int v2);
    bool ExisteArista(int v1, int v2);
    int PesoArista(int v1, int v2);
}

public class GrafoMA : MonoBehaviour, GrafoTDA
{
    static int n = 100;
    public int[,] MAdy;
    public int[,] MId;
    public int[] Etiqs;
    public int cantNodos;

    public void InicializarGrafo()
    {
        MAdy = new int[n, n];
        MId = new int[n, n];
        Etiqs = new int[n];
        cantNodos = 0;
    }

    public void AgregarVertice(int v)
    {
        Etiqs[cantNodos] = v;
        for (int i = 0; i <= cantNodos; i++)
        {
            MAdy[cantNodos, i] = 0;
            MAdy[i, cantNodos] = 0;
        }
        cantNodos++;
    }

    public void EliminarVertice(int v)
    {
        int ind = Vert2Indice(v);

        for (int k = 0; k < cantNodos; k++)
        {
            MAdy[k, ind] = MAdy[k, cantNodos - 1];
        }

        for (int k = 0; k < cantNodos; k++)
        {
            MAdy[ind, k] = MAdy[cantNodos - 1, k];
        }

        Etiqs[ind] = Etiqs[cantNodos - 1];
        cantNodos--;
    }

    public int Vert2Indice(int v)
    {
        int i = cantNodos - 1;
        while (i >= 0 && Etiqs[i] != v)
        {
            i--;
        }

        return i;
    }

    // Uso del Dijkstra
    public string ObtenerCaminoMasCorto(int origen, int destino)
    {
        AlgDijkstra.Dijkstra(this, origen);

        int indiceDestino = Vert2Indice(destino);

        if (AlgDijkstra.distance[indiceDestino] == int.MaxValue)
        {
            return "No hay camino";
        }

        return AlgDijkstra.nodos[indiceDestino];
    }

    public void ImprimirResultadosDijkstra()
    {
        Debug.Log("Distancias desde el origen:");
        for (int i = 0; i < AlgDijkstra.distance.Length; i++)
        {
            Debug.Log($"{Etiqs[i]}: {AlgDijkstra.distance[i]}");
        }

        Debug.Log("Caminos:");
        for (int i = 0; i < AlgDijkstra.nodos.Length; i++)
        {
            Debug.Log($"{Etiqs[i]}: {AlgDijkstra.nodos[i]}");
        }
    }
    // Termina uso del Dijkstra

    public ConjuntoTDA Vertices()
    {
        ConjuntoTDA Vert = new ConjuntoTA();
        Vert.InicializarConjunto();
        for (int i = 0; i < cantNodos; i++)
        {
            Vert.Agregar(Etiqs[i]);
        }
        return Vert;
    }

    public void AgregarArista(int id, int v1, int v2, int peso)
    {
        int o = Vert2Indice(v1);
        int d = Vert2Indice(v2);
        MAdy[o, d] = peso;
        MId[o, d] = id;
    }

    public void EliminarArista(int v1, int v2)
    {
        int o = Vert2Indice(v1);
        int d = Vert2Indice(v2);
        MAdy[o, d] = 0;
        MId[o, d] = 0;
    }

    public bool ExisteArista(int v1, int v2)
    {
        int o = Vert2Indice(v1);
        int d = Vert2Indice(v2);
        return MAdy[o, d] != 0;
    }

    public int PesoArista(int v1, int v2)
    {
        int o = Vert2Indice(v1);
        int d = Vert2Indice(v2);
        return MAdy[o, d];
    }
}

public interface ConjuntoTDA
{
    void InicializarConjunto();
    bool ConjuntoVacio();
    void Agregar(int x);
    int Elegir();
    void Sacar(int x);
    bool Pertenece(int x);
}

public class ConjuntoTA : ConjuntoTDA
{
    int[] a;
    int cant;

    public void Agregar(int x)
    {
        if (!this.Pertenece(x))
        {
            a[cant] = x;
            cant++;
        }
    }

    public bool ConjuntoVacio()
    {
        return cant == 0;
    }

    public int Elegir()
    {
        return a[cant - 1];
    }

    public void InicializarConjunto()
    {
        a = new int[100]; // o el tamaño que desees
        cant = 0;
    }

    public bool Pertenece(int x)
    {
        int i = 0;
        while (i < cant && a[i] != x)
        {
            i++;
        }
        return (i < cant);
    }

    public void Sacar(int x)
    {
        int i = 0;
        while (i < cant && a[i] != x)
        {
            i++;
        }
        if (i < cant)
        {
            a[i] = a[cant - 1];
            cant--;
        }
    }
}


using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GrafoManager : MonoBehaviour
{
    public GrafoMA grafoInteracciones;

    void Start()
    {
        grafoInteracciones = new GrafoMA();
        grafoInteracciones.InicializarGrafo();

        grafoInteracciones.AgregarVertice(101); //Player
        grafoInteracciones.AgregarVertice(102); //Objeto
        grafoInteracciones.AgregarVertice(103); //NuevoObjeto
        grafoInteracciones.AgregarVertice(104); //Mago
       
        grafoInteracciones.AgregarArista(1, 101, 102, 10); //player X objeto
        grafoInteracciones.AgregarArista(2, 102, 103, 20); //player X NuevoObjeto 
        grafoInteracciones.AgregarArista(3, 103, 104, 30); //player X mago
    }
}
